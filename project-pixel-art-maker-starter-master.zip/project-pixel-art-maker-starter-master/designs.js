// Select color input
// Select size input

// When size is submitted by the user, call makeGrid()

let heightElement=document.getElementById('inputHeight');
let widthElement=document.getElementById('inputWidth');

let formElement=document.getElementById('sizePicker');
let gridElement=document.getElementById('pixelCanvas');

let colorElement=document.getElementById('colorPicker');


formElement.addEventListener('submit',(event)=>{
	event.preventDefault();
	makeGrid(heightElement.value,widthElement.value); })






function makeGrid(height,width) 
{

// Your code goes here!

	gridElement.innerHTML='';
	for(let i=0;i<height;i++)
	{
		let row = document.createElement("tr");
		for(let j=0;j<width;j++)
		{

			let cell = document.createElement("td");
			cell.addEventListener('click',(event)=>{ 
				event.preventDefault();
				makeColor(cell);
			})
			row.appendChild(cell);
		}

		gridElement.appendChild(row);
	}

}

function makeColor(cell)
{
	
	
	cell.style.background=colorElement.value;
}

